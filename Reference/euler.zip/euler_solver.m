function euler_solver( euler_method, n, dt, x0, v0, color)
x1 = x0;
v1 = v0;
x_e = zeros(n, 2);
x_e(1, :) = x1;
for i = 2 : n
    [x2, v2] = euler_method(x1, v1, dt);
    x_e(i, :) = x2;
    x1 = x2;
    v1 = v2;
end
plot(x_e(:, 1), x_e(:, 2), color);
end

