clc;
clear;
t = (0:.01:2 * pi)';
x = cos(t);
y = sin(t);
hold on;
axis square;
% axis_limit = 2;
axis_limit = 1.5;
axis([-axis_limit, axis_limit, -axis_limit, axis_limit]);
plot(x,y,'--r');
x0 = [1,  0];
v0 = [0, -1];
i = 1;
dt = [1, 0.5, 0.25, 0.1, 0.05];
n = floor(6 * pi ./ dt);
% explicit euler
euler_solver(@explicit_euler, n(i), dt(i), x0, v0, '-ob');
% implicit euler
%euler_solver(@implicit_euler, n(i), dt(i), x0, v0, '-og');
% semi-implicit euler
%euler_solver(@semi_implicit_euler, n(i), dt(i), x0, v0, '-ok');
%legend('Analytical Solution', 'Explicit Euler Method');
%legend('Analytical Solution', 'Explicit Euler Method', 'Implicit Euler Method', 'Semi-implicit Euler Method');
