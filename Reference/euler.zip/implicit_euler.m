function [ x2, v2 ] = implicit_euler( x1, v1, dt )
% f = -x2;
% v2 = v1 + f * dt;
% x2 = x1 + v2 * dt;
x2 = (x1 + v1 * dt) / (1 + dt * dt);
f = -x2;
v2 = v1 + f * dt;
end

