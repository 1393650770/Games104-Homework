function [ x2, v2 ] = explicit_euler( x1, v1, dt )
f = -x1;
v2 = v1 + f * dt;
x2 = x1 + v1 * dt;
end

